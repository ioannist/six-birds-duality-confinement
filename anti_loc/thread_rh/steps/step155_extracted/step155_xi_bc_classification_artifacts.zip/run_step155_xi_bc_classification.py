from pathlib import Path
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

base = Path('/mnt/data/rh_membrane_step155_xi_bc_classification')

# Route score model: 0 blocked, 1 open, 2 accepted/closed
routes = pd.DataFrame([
    {'route':'co-Poisson\nfactorization','proof_status':1.0,'proof_producing':1.0,'accepted_now':0.0},
    {'route':'commutator\ncancellation','proof_status':1.0,'proof_producing':1.0,'accepted_now':0.0},
    {'route':'compact/tail\npayment','proof_status':0.6,'proof_producing':0.8,'accepted_now':0.0},
    {'route':'positive source\nabsorption','proof_status':0.2,'proof_producing':0.1,'accepted_now':0.0},
    {'route':'scoped Xi\nnonclaim','proof_status':2.0,'proof_producing':0.6,'accepted_now':1.0},
])
routes.to_csv(base/'xi_bc_route_scores_step155.csv', index=False)

plt.figure(figsize=(8,4.8))
x = np.arange(len(routes))
width = 0.25
plt.bar(x-width, routes['proof_status'], width, label='classification status')
plt.bar(x, routes['proof_producing'], width, label='proof-producing potential')
plt.bar(x+width, routes['accepted_now'], width, label='accepted now')
plt.xticks(x, routes['route'], rotation=25, ha='right')
plt.ylabel('score')
plt.title('Step 155 route classification')
plt.legend()
plt.tight_layout()
plt.savefig(base/'xi_bc_route_classification_step155.png', dpi=180)
plt.close()

# Diagnostic route pivot plot
N = np.arange(1, 41)
Lambda = np.log1p(N)**1.4
residual_mass = 0.08
source_budget_ratio = residual_mass + 0.25/np.sqrt(N)  # cannot go below residual mass
collapse_target = 0.25/np.sqrt(N)
plt.figure(figsize=(7,4.5))
plt.plot(N, source_budget_ratio, label='positive source budget ratio')
plt.plot(N, collapse_target, label='desired collapse-to-zero profile')
plt.axhline(residual_mass, linestyle='--', label='fixed residual mass floor')
plt.xlabel('window N')
plt.ylabel('normalized exposure')
plt.title('No-free source-budget obstruction')
plt.legend()
plt.tight_layout()
plt.savefig(base/'source_budget_floor_step155.png', dpi=180)
plt.close()

# Residual trichotomy simulated defect plot
N = np.arange(1, 60)
compact_defect = 0.75 + 0.05*np.sin(N/5)  # plateau, not tail-decaying
source_defect = 0.45 + 0.18/np.sqrt(N)    # positive floor
scoped_defect = np.full_like(N, 0.55, dtype=float)
plt.figure(figsize=(7,4.5))
plt.plot(N, compact_defect, label='compact/tail route: plateau')
plt.plot(N, source_defect, label='source route: positive floor')
plt.plot(N, scoped_defect, label='scoped residual carried')
plt.xlabel('audit window N')
plt.ylabel('residual defect proxy')
plt.title('Xi^BC classification regimes')
plt.legend()
plt.tight_layout()
plt.savefig(base/'xi_bc_classification_regimes_step155.png', dpi=180)
plt.close()

# Kernel spectrum toy
vals = np.concatenate([np.linspace(1.2,0.2,12), 0.08*np.exp(-np.linspace(0,3,20))])
spectrum = pd.DataFrame({'index':np.arange(len(vals)), 'eigenvalue_proxy':vals})
spectrum.to_csv(base/'xi_bc_kernel_spectrum_proxy_step155.csv', index=False)
plt.figure(figsize=(7,4.5))
plt.semilogy(spectrum['index'], spectrum['eigenvalue_proxy'], marker='o')
plt.xlabel('index')
plt.ylabel('eigenvalue proxy')
plt.title('Positive residual kernel: active spectrum proxy')
plt.tight_layout()
plt.savefig(base/'xi_bc_kernel_spectrum_proxy_step155.png', dpi=180)
plt.close()

# Check files
required = [
    'xi_bc_residual_classification_step155.tex',
    'step155_results_summary.md',
    'xi_bc_classification_gate_table_step155.csv',
    'xi_bc_route_status_step155.csv',
    'theorem_map_step155.csv',
    'construction_tasks_step155.csv',
    'nonclaim_boundary_step155.md',
    'step155_schema.json'
]
checks = {name: (base/name).exists() and (base/name).stat().st_size > 0 for name in required}
checks['plots_created'] = all((base/name).exists() for name in [
    'xi_bc_route_classification_step155.png',
    'source_budget_floor_step155.png',
    'xi_bc_classification_regimes_step155.png',
    'xi_bc_kernel_spectrum_proxy_step155.png'
])
checks['csv_created'] = all((base/name).exists() for name in [
    'xi_bc_route_scores_step155.csv',
    'xi_bc_kernel_spectrum_proxy_step155.csv'
])
(base/'step155_check_results.json').write_text(json.dumps(checks, indent=2))
print(json.dumps(checks, indent=2))
