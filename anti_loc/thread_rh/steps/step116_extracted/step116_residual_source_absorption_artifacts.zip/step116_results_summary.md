
# Step 116: Residual-Specific Hecke/Dirichlet Source Absorption for \(\Xi^{\rm BC}\)

This step converts the boundary-to-co-Poisson residual from Step 115 into an explicit source-coercivity theorem.

The active residual is

\[
\Xi^{\rm BC}_{\ell,a}=\mathfrak B_{\ell,a}^{*}\Pi_{Y_a}\mathfrak B_{\ell,a}\succeq0.
\]

It measures the part of the shifted Sonin/prolate boundary packet that is still seen by Burnol's zero-evaluator span \(Y_a\). If the clean zeta-factorization route fails, this residual must be source-absorbed.

## Main theorem

For a finite residual sector with Gram \(G_{R,N}\), coefficient map \(R_N\), coefficient-space source Gram \(G_{\mathcal X,N}\), and source frame

\[
F_{R,N}=R_N^*G_{\mathcal X,N}R_N,
\]

if

\[
G_{\mathcal X,N}\succeq \gamma_NH_N,
\]

and

\[
R_N^*H_NR_N\succeq c_{R,N}G_{R,N},
\]

then

\[
F_{R,N}\succeq \gamma_Nc_{R,N}G_{R,N}.
\]

If additionally

\[
\Xi_N^{\rm BC}\preceq \sigma_NG_{R,N}+T_N^{\rm BC},
\]

then

\[
\Xi_N^{\rm BC}\preceq \frac{\sigma_N}{\gamma_Nc_{R,N}}F_{R,N}+T_N^{\rm BC}.
\]

So the residual is absorbed when

\[
\gamma_Nc_{R,N}\to\infty
\]

and the residual tail vanishes in the fixed/exhaustive ledger sense.

## Meaning

\(\gamma_N\) is character/source strength.

\(c_{R,N}\) is residual coefficient visibility.

Heap--Soundararajan-style moment technology is relevant to \(\gamma_N\). Burnol/co-Poisson density and coefficient adequacy are relevant to \(c_{R,N}\).

The source route works only if both combine:

\[
\Lambda_N=\gamma_Nc_{R,N}\to\infty.
\]

## Bottom line

Step 116 makes the fallback route precise:

\[
\boxed{\Xi^{\rm BC}\text{ must either vanish by co-Poisson inclusion or be absorbed by a residual-specific Hecke/Dirichlet lower frame.}}
\]
