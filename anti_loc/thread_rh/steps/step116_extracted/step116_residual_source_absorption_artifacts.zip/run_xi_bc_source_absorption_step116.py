import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import json

OUT = Path('/mnt/data/rh_membrane_step116_xi_bc_source_absorption')
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(116)

def psd_sqrt(A):
    w, V = np.linalg.eigh((A+A.T.conj())/2)
    w = np.maximum(w, 0)
    return V @ np.diag(np.sqrt(w)) @ V.T.conj()

def min_gen_eig(A,B,eps=1e-10):
    # min eigenvalue of B^{-1/2} A B^{-1/2} on support of B
    w,V = np.linalg.eigh((B+B.T.conj())/2)
    keep = w > eps
    if not np.any(keep): return np.nan
    Binv2 = V[:,keep] @ np.diag(1/np.sqrt(w[keep])) @ V[:,keep].T.conj()
    C = Binv2.T.conj() @ ((A+A.T.conj())/2) @ Binv2
    return float(np.linalg.eigvalsh((C+C.T.conj())/2).min())

def make_spd(n, cond=20):
    Q,_ = np.linalg.qr(rng.normal(size=(n,n)))
    vals = np.geomspace(1, cond, n)
    return Q @ np.diag(vals) @ Q.T

# Main finite theorem check: Xi = Z^*Z; R coefficient map; G source matrix.
rows=[]
for trial in range(60):
    dim = rng.integers(5,14)
    coeff = rng.integers(dim+3, dim+18)
    # residual map Z, full rank on boundary dimension
    Z = rng.normal(size=(coeff, dim))
    Xi = Z.T @ Z + 0.05*np.eye(dim)
    # coefficient visibility operator R^* H R = Cvis, force a known c by construction
    c_target = rng.uniform(0.05, 0.9)
    H = make_spd(coeff, cond=5)
    # Choose R so that R^T H R = c_target Xi + extra PSD.
    # Use H^{-1/2} [sqrt(c) Xi^{1/2}; plus dimensions] construction via coeff x dim matrix.
    H_inv2 = np.linalg.inv(psd_sqrt(H))
    Xi2 = psd_sqrt(Xi)
    R = H_inv2 @ (np.sqrt(c_target) * np.vstack([Xi2, np.zeros((coeff-dim, dim))]) if coeff>=dim else np.sqrt(c_target)*Xi2[:coeff,:])
    # Add small random visible component if dimensions allow
    R += 0.02*rng.normal(size=(coeff,dim))
    Cvis = R.T @ H @ R
    c_actual = min_gen_eig(Cvis, Xi)
    gamma = rng.uniform(1,30)
    # Source Gram G >= gamma H
    A = rng.normal(size=(coeff, coeff))
    E = A.T @ A / coeff
    G = gamma*H + E
    F = R.T @ G @ R
    min_slack = min_gen_eig(F - gamma*c_actual*Xi, Xi)
    rows.append(dict(trial=trial, dim=dim, coeff_dim=coeff, c_target=c_target, c_actual=c_actual, gamma=gamma, Lambda=gamma*c_actual, min_generalized_slack=min_slack))

pd.DataFrame(rows).to_csv(OUT/'finite_residual_absorption_checks_step116.csv', index=False)

# Visibility vs atom extension model: epsilon decreases in three scenarios
N = np.arange(4,101,4)
models=[]
for name, alpha, floor in [('burnol_native_good',0.65,0.02),('ordinary_dirichlet_fragile',0.18,0.65),('hybrid_copoisson',0.40,0.20)]:
    eps = floor + (1-floor)*np.exp(-alpha*np.sqrt(N/4))
    c = 1-eps**2
    for n,e,cc in zip(N, eps, c):
        models.append(dict(model=name,N=int(n),epsilon=float(e),c_xi=float(cc)))
vis_df=pd.DataFrame(models)
vis_df.to_csv(OUT/'residual_visibility_scenarios_step116.csv', index=False)
plt.figure(figsize=(7,4.5))
for name,grp in vis_df.groupby('model'):
    plt.plot(grp['N'], grp['c_xi'], marker='o', label=name)
plt.xlabel('declared atom/window count N')
plt.ylabel(r'residual visibility $c_{\Xi,N}$')
plt.title('Residual-specific coefficient visibility scenarios')
plt.legend()
plt.tight_layout()
plt.savefig(OUT/'residual_visibility_scenarios_step116.png', dpi=180)
plt.close()

# Effective absorption product gamma*c.
gamma = 0.25*np.log1p(N)**2 + 0.05*N**0.6
prod=[]
for name, grp in vis_df.groupby('model'):
    for n, cc, g in zip(grp['N'], grp['c_xi'], gamma):
        prod.append(dict(model=name,N=int(n),gamma=float(g),c_xi=float(cc),Lambda_eff=float(g*cc),residual_budget=float(1/(g*cc) if g*cc>0 else np.inf)))
prod_df=pd.DataFrame(prod)
prod_df.to_csv(OUT/'residual_effective_source_strength_step116.csv', index=False)
plt.figure(figsize=(7,4.5))
for name,grp in prod_df.groupby('model'):
    plt.plot(grp['N'], grp['Lambda_eff'], marker='o', label=name)
plt.xlabel('N')
plt.ylabel(r'effective residual source strength $\gamma_N c_{\Xi,N}$')
plt.title('Residual absorption requires product growth')
plt.legend()
plt.tight_layout()
plt.savefig(OUT/'residual_effective_source_strength_step116.png', dpi=180)
plt.close()

# Partial source coverage failure: rank deficient source Gram misses residual directions.
dim=24
rank_vals=np.arange(2,25,2)
fail=[]
for r in rank_vals:
    P=np.zeros((dim,dim)); P[:r,:r]=np.eye(r)
    # residual Xi full identity in residual basis
    eigs=np.linalg.eigvalsh(P)
    fail.append(dict(source_rank=int(r),min_eigenvalue=float(eigs.min()),covered_fraction=float(r/dim),uncovered_dim=int(dim-r)))
pd.DataFrame(fail).to_csv(OUT/'residual_partial_source_failure_step116.csv', index=False)
plt.figure(figsize=(7,4.5))
plt.plot([x['covered_fraction'] for x in fail],[x['min_eigenvalue'] for x in fail], marker='o')
plt.xlabel('covered fraction of residual sector')
plt.ylabel('minimum residual-frame eigenvalue')
plt.title('Partial residual-sector source coverage fails')
plt.tight_layout()
plt.savefig(OUT/'residual_partial_source_failure_step116.png', dpi=180)
plt.close()

# Tail/exhaustivity model for residual sector
tail=[]
N2=np.arange(10,210,10)
for rate,label in [(0.5,'trace_tail_fast'),(0.18,'trace_tail_slow'),(0.0,'nonvanishing_tail')]:
    for n in N2:
        t = 0.05+np.exp(-rate*np.sqrt(n)) if rate>0 else 0.35+0.02*np.sin(n/15)
        tail.append(dict(model=label,N=int(n),tail_trace=float(t)))
tail_df=pd.DataFrame(tail)
tail_df.to_csv(OUT/'residual_tail_exhaustivity_step116.csv', index=False)
plt.figure(figsize=(7,4.5))
for label, grp in tail_df.groupby('model'):
    plt.plot(grp['N'], grp['tail_trace'], marker='o', label=label)
plt.xlabel('window N')
plt.ylabel('residual tail trace')
plt.title('Residual-sector fixed/exhaustive tail requirement')
plt.legend()
plt.tight_layout()
plt.savefig(OUT/'residual_tail_exhaustivity_step116.png', dpi=180)
plt.close()

# Gate tables
gate_rows=[
    ('G1 residual definition','Define Xi_BC = B^* Pi_Y B on a fixed/exhaustive residual sector','accepted formal'),
    ('G2 residual coefficient visibility','Prove R_Xi^* H R_Xi >= c_Xi Xi_BC','open analytic'),
    ('G3 character/source matrix lower frame','Prove G_X >= gamma H, not scalar-only lower moment','open analytic'),
    ('G4 product growth','Show gamma_N c_Xi,N -> infinity','open arithmetic/visibility'),
    ('G5 tail promotion','Residual finite windows exhaust fixed Xi_BC ledger','open tail record'),
    ('G6 no smuggling','Character family and atoms declared upstream, not chosen from residual eigenvectors','discipline required'),
    ('G7 all-six records','P1-P6 statuses for residual source bridge','framework required'),
    ('G8 nonclaim','If c_Xi collapses or tail persists, downgrade to support-only','required'),
]
pd.DataFrame(gate_rows, columns=['gate','requirement','status']).to_csv(OUT/'xi_bc_source_gate_table_step116.csv', index=False)

arith_rows=[
    ('Burnol/Sonine residual sector','Identify Y_a, P_a, Xi_BC on L_a and finite windows','carrier/exhaustivity'),
    ('Residual coefficient map','Construct R_Xi,N from co-Poisson/Burnol atoms to coefficient space','visibility c_Xi'),
    ('Heap-Soundararajan lift','Upgrade scalar lower moments to matrix lower frame G_X >= gamma H','source strength gamma'),
    ('Dirichlet/Hecke character family','Use upstream-visible complete/exhaustive character windows','non-smuggled sources'),
    ('Tail/exhaustivity','Promote finite residual windows to fixed completed residual ledger','exact confinement'),
    ('Conrey-Li survival','Avoid RKHS shift-positivity collapse','nonclaim boundary'),
]
pd.DataFrame(arith_rows, columns=['input','description','role']).to_csv(OUT/'arithmetic_input_table_step116.csv', index=False)

route_rows=[
    ('compact repair','blocked for raw shifted Sonin blocks unless essential semilocal prolate cancellation appears'),
    ('zeta factorization','not automatic; raw log shift does not create a zeta factor'),
    ('co-Poisson visibility','works only on portion of residual lying in declared co-Poisson span'),
    ('residual source absorption','active route; requires gamma_N c_Xi,N -> infinity plus tail'),
]
pd.DataFrame(route_rows, columns=['route','status']).to_csv(OUT/'route_status_step116.csv', index=False)

schema={
    'step':116,
    'name':'Residual-specific Hecke/Dirichlet source absorption for Xi_BC',
    'objects':['Xi_BC','residual_sector','R_Xi_N','G_X_N','gamma_N','c_Xi_N','tail_T_N'],
    'main_implication':'G_X_N >= gamma_N H_N and R_Xi_N^* H_N R_Xi_N >= c_Xi_N Xi_BC_N imply source absorption with strength gamma_N c_Xi_N',
    'nonclaim':'Does not prove RH; states the residual-specific source absorption gate.'
}
(OUT/'step116_schema.json').write_text(json.dumps(schema, indent=2))

# simple theorem map
thm_rows=[
    ('T1','Residual absorption prototype','If F_N >= Lambda_N Xi_N then Xi_N <= Lambda_N^{-1}F_N'),
    ('T2','Matrix moment residual lift','G_X>=gamma H and R_Xi^*HR_Xi>=c_Xi Xi imply R_Xi^*G_XR_Xi>=gamma c_Xi Xi'),
    ('T3','Visibility residual identity','c_Xi=1-||(I-P_D)Z_Xi Xi^{-1/2}||^2'),
    ('T4','Tail promotion','Finite residual absorption promotes only with fixed/exhaustive tail'),
]
pd.DataFrame(thm_rows, columns=['id','name','statement']).to_csv(OUT/'theorem_map_step116.csv', index=False)

# nonclaim and summary written separately in bash maybe
print('Wrote Step 116 artifacts to', OUT)
