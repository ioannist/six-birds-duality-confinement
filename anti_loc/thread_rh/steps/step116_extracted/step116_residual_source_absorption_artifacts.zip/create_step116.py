import json, zipfile, os, math
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

out=Path('/mnt/data/rh_membrane_step116_xi_bc_source_absorption')
out.mkdir(exist_ok=True)

tex = r'''
\documentclass[11pt]{article}
\usepackage{amsmath,amssymb,amsthm,mathtools}
\usepackage{enumitem}
\usepackage{geometry}
\geometry{margin=1in}
\newtheorem{theorem}{Theorem}
\newtheorem{lemma}{Lemma}
\newtheorem{definition}{Definition}
\newtheorem{proposition}{Proposition}
\newtheorem{corollary}{Corollary}
\newcommand{\BC}{\mathrm{BC}}
\newcommand{\Ran}{\operatorname{Ran}}
\newcommand{\Ker}{\operatorname{Ker}}
\newcommand{\diag}{\operatorname{diag}}
\newcommand{\Tr}{\operatorname{Tr}}
\title{Step 116: Residual-Specific Hecke/Dirichlet Source Absorption for $\Xi^{\rm BC}$}
\author{RATCHET RH Membrane Program}
\date{May 14, 2026}
\begin{document}
\maketitle

\section{Purpose}
Steps 114--115 reduced the Burnol/co-Poisson visibility shortcut to the zero-evaluator residual
\[
\Xi^{\BC}_{\ell,a}=\mathfrak B_{\ell,a}^{*}\Pi_{Y_a}\mathfrak B_{\ell,a}\succeq0,
\]
where $Y_a$ is Burnol's zeta-zero evaluator span in $L_a$, $P_a=Y_a^\perp$ is the co-Poisson subspace, and $\mathfrak B_{\ell,a}$ is a shifted semilocal boundary block transported into the Burnol carrier.

The present note states the source-absorption theorem for the case in which the clean zeta-factorization route
\[
M(\mathfrak B_{\ell,a}u)(s)=\zeta(s)\alpha_{\ell,u}(s)
\]
is not available. The target is to charge the residual sector seen by $\Pi_{Y_a}\mathfrak B_{\ell,a}$ using a non-smuggled Hecke/Dirichlet source frame.

\section{Residual sector}
\begin{definition}[Boundary-to-co-Poisson residual sector]
For a finite set of log-shift modes $\mathcal L_N$, define
\[
\mathcal R_N
=\overline{\operatorname{span}}\{\Ran |\Pi_{Y_a}\mathfrak B_{\ell,a}|:\ell\in\mathcal L_N\}\subseteq Y_a.
\]
Let $M_{R,N}:\mathbb C^{d_N}\to Y_a$ synthesize a finite dictionary for $\mathcal R_N$, and set
\[
G_{R,N}=M_{R,N}^*M_{R,N}.
\]
The finite residual form is
\[
\Xi^{\BC}_N\preceq \sigma_N G_{R,N}+T_N^{\BC},
\]
where $T_N^{\BC}$ is the finite-to-completed residual tail.
\end{definition}

\section{Residual coefficient visibility}
Let $D_N:\mathbb C^{I_N}\to H_N$ be a declared coefficient synthesis dictionary, typically Burnol/co-Poisson native followed by a Dirichlet/Hecke coefficient readout. Let $P_{D,N}$ be the projection onto $\Ran D_N$. The residual coefficient map is
\[
R_N=D_N^\dagger M_{R,N}.
\]
The coefficient visibility identity is
\[
R_N^*H_NR_N
=M_{R,N}^*P_{D,N}M_{R,N}
=G_{R,N}-E_{R,N}^*E_{R,N},
\]
where
\[
E_{R,N}=(I-P_{D,N})M_{R,N}.
\]
Thus the residual visibility constant is
\[
c_{R,N}=1-\|E_{R,N}G_{R,N}^{-1/2}\|^2.
\]
This is the residual-specific $\Xi$ adequacy gate: it measures what the residual sector sees that the coefficient dictionary cannot express.

\section{Source frame}
Let $\mathcal X_N$ be an upstream-declared character/source family. Define its coefficient-space Gram matrix by
\[
G_{\mathcal X,N}(m,n)
=\sum_{\omega\in\mathcal X_N}\lambda_{\omega,N}\omega(n)\overline{\omega(m)}.
\]
The induced residual source frame is
\[
F_{R,N}=R_N^*G_{\mathcal X,N}R_N.
\]

\begin{theorem}[Finite residual source absorption]
Assume
\[
G_{\mathcal X,N}\succeq \gamma_N H_N,
\qquad
R_N^*H_NR_N\succeq c_{R,N}G_{R,N}.
\]
Then
\[
F_{R,N}\succeq \gamma_Nc_{R,N}G_{R,N}.
\]
If additionally
\[
\Xi^{\BC}_N\preceq \sigma_NG_{R,N}+T_N^{\BC},
\]
then
\[
\Xi^{\BC}_N\preceq \frac{\sigma_N}{\gamma_Nc_{R,N}}F_{R,N}+T_N^{\BC}.
\]
In particular, the residual is source-absorbed when
\[
\gamma_Nc_{R,N}\to\infty,
\qquad
T_N^{\BC}\to0
\]
in the fixed/exhaustive ledger sense.
\end{theorem}

\begin{proof}
The first inequality follows by congruence:
\[
F_{R,N}=R_N^*G_{\mathcal X,N}R_N\succeq \gamma_NR_N^*H_NR_N\succeq \gamma_Nc_{R,N}G_{R,N}.
\]
Thus
\[
G_{R,N}\preceq (\gamma_Nc_{R,N})^{-1}F_{R,N},
\]
and substitution into the residual domination estimate gives the result.
\end{proof}

\section{Completed theorem shape}
Let $\mathcal R$ be the completed boundary-to-co-Poisson residual sector. A completed source absorption record consists of finite windows $\Pi_N:\mathcal R\to\mathcal R_N$ and tails $T_N$ such that
\[
\Xi^{\BC}\preceq \iota_N\Xi^{\BC}_N\iota_N^*+T_N,
\qquad
\Tr T_N\to0,
\]
together with finite source frames satisfying
\[
F_{R,N}\succeq \Lambda_NG_{R,N}-E_{R,N}^{\rm src},
\qquad
\Lambda_N=\gamma_Nc_{R,N}\to\infty,
\]
and defects satisfying the fixed/exhaustive ledger budget.

Then $\Xi^{\BC}$ is absorbed by the source ladder. If the rest of the semilocal membrane records pass, this closes the boundary residual left by the failure of automatic co-Poisson inclusion.

\section{No-smuggling discipline}
The source family $\mathcal X_N$, the coefficient dictionary $D_N$, the residual windows, and the weights $\lambda_{\omega,N}$ must be declared upstream from the arithmetic carrier. They cannot be selected because they make a final zero-confinement inequality pass. Zero simplicity is not an allowed assumption in this route.

\section{Interpretation}
The dangerous shifted boundary packets may have a component seen by the zero-evaluator sector. That component is $\Xi^{\BC}$. Step 116 says: if the co-Poisson atom language cannot make it vanish, then Hecke/Dirichlet sources must see and charge it. The two required constants are
\[
\gamma_N=\text{character/source strength},\qquad c_{R,N}=\text{residual coefficient visibility}.
\]
The route advances only if
\[
\gamma_Nc_{R,N}\to\infty.
\]

\end{document}
'''
(out/'boundary_residual_source_absorption_step116.tex').write_text(tex)

summary = r'''
# Step 116: Residual-Specific Hecke/Dirichlet Source Absorption for \(\Xi^{\rm BC}\)

This step converts the boundary-to-co-Poisson residual from Step 115 into an explicit source-coercivity theorem.

The active residual is

\[
\Xi^{\rm BC}_{\ell,a}=\mathfrak B_{\ell,a}^{*}\Pi_{Y_a}\mathfrak B_{\ell,a}\succeq0.
\]

It measures the part of the shifted Sonin/prolate boundary packet that is still seen by Burnol's zero-evaluator span \(Y_a\). If the clean zeta-factorization route fails, this residual must be source-absorbed.

## Main theorem

For a finite residual sector with Gram \(G_{R,N}\), coefficient map \(R_N\), coefficient-space source Gram \(G_{\mathcal X,N}\), and source frame

\[
F_{R,N}=R_N^*G_{\mathcal X,N}R_N,
\]

if

\[
G_{\mathcal X,N}\succeq \gamma_NH_N,
\]

and

\[
R_N^*H_NR_N\succeq c_{R,N}G_{R,N},
\]

then

\[
F_{R,N}\succeq \gamma_Nc_{R,N}G_{R,N}.
\]

If additionally

\[
\Xi_N^{\rm BC}\preceq \sigma_NG_{R,N}+T_N^{\rm BC},
\]

then

\[
\Xi_N^{\rm BC}\preceq \frac{\sigma_N}{\gamma_Nc_{R,N}}F_{R,N}+T_N^{\rm BC}.
\]

So the residual is absorbed when

\[
\gamma_Nc_{R,N}\to\infty
\]

and the residual tail vanishes in the fixed/exhaustive ledger sense.

## Meaning

\(\gamma_N\) is character/source strength.

\(c_{R,N}\) is residual coefficient visibility.

Heap--Soundararajan-style moment technology is relevant to \(\gamma_N\). Burnol/co-Poisson density and coefficient adequacy are relevant to \(c_{R,N}\).

The source route works only if both combine:

\[
\Lambda_N=\gamma_Nc_{R,N}\to\infty.
\]

## Bottom line

Step 116 makes the fallback route precise:

\[
\boxed{\Xi^{\rm BC}\text{ must either vanish by co-Poisson inclusion or be absorbed by a residual-specific Hecke/Dirichlet lower frame.}}
\]
'''
(out/'step116_results_summary.md').write_text(summary)

# tables
pd.DataFrame([
    {'gate':'Residual sector declaration','mathematical record':'M_{R,N}, G_{R,N}, Xi^{BC}_N','accepted if':'residual windows declared before source selection','failure mode':'target-selected residual dictionary'},
    {'gate':'Residual domination','mathematical record':'Xi^{BC}_N <= sigma_N G_{R,N}+T_N','accepted if':'sigma_N finite and tail recorded','failure mode':'unbounded residual sector'},
    {'gate':'Coefficient visibility','mathematical record':'R_N^* H_N R_N >= c_{R,N} G_{R,N}','accepted if':'c_{R,N}>0 and not collapsing too fast','failure mode':'coefficient blind spot / ker R_N'},
    {'gate':'Character/source strength','mathematical record':'G_X,N >= gamma_N H_N','accepted if':'matrix lower bound for all coefficient directions','failure mode':'scalar moment only / rank-one evidence'},
    {'gate':'Effective lower frame','mathematical record':'Lambda_N=gamma_N c_{R,N}','accepted if':'Lambda_N -> infinity','failure mode':'source strength cannot overcome visibility collapse'},
    {'gate':'Completed promotion','mathematical record':'fixed/exhaustive tail T_N -> 0','accepted if':'tail vanishes on completed residual ledger','failure mode':'moving-window support only'},
    {'gate':'No-smuggling','mathematical record':'X_N, D_N, weights upstream-declared','accepted if':'chosen from carrier arithmetic, not final zeros','failure mode':'target-selected source family'},
]).to_csv(out/'residual_source_absorption_gate_table_step116.csv', index=False)

pd.DataFrame([
    {'input':'Burnol residual carrier','needed statement':'Y_a zero-evaluator span and P_a=Y_a^perp co-Poisson complement; residual Xi^{BC}=B^*Pi_YB','source':'Burnol Sonine/co-Poisson corpus','status':'carrier backbone'},
    {'input':'co-Poisson atom density','needed statement':'declared atom spaces exhaust the coefficient-visible residual sector','source':'Burnol generator/co-Poisson synthesis','status':'visibility c_R,N'},
    {'input':'matrix lower moments','needed statement':'G_X,N >= gamma_N H_N, not merely scalar lower moment','source':'Heap--Soundararajan operator-valued lift target','status':'source strength gamma_N'},
    {'input':'finite character orthogonality','needed statement':'complete finite character families give local tight frames','source':'Dirichlet character orthogonality','status':'finite-window support'},
    {'input':'Plancherel/exhaustivity','needed statement':'finite windows promote to completed residual sector with vanishing tail','source':'Hecke/idèle Plancherel / semilocal carrier','status':'completed promotion'},
    {'input':'semilocal response geometry','needed statement':'finite Euler factors live in same Hardy--Titchmarsh response room','source':'CCM semilocal framework','status':'ambient geometry'},
]).to_csv(out/'arithmetic_input_table_step116.csv', index=False)

pd.DataFrame([
    {'theorem':'Residual source absorption','claim':'gamma_N and c_R,N imply F_R,N >= gamma_N c_R,N G_R,N','status':'proved finite linear algebra'},
    {'theorem':'Residual domination transfer','claim':'Xi_N^BC <= sigma_N G_R,N + T_N implies Xi_N^BC <= sigma/(gamma c) F_R,N + T_N','status':'proved finite linear algebra'},
    {'theorem':'Completed residual absorption','claim':'finite absorption plus fixed/exhaustive tail absorbs Xi^BC','status':'conditional theorem schema'},
    {'theorem':'No scalar-to-matrix overread','claim':'scalar lower moments do not imply source lower frame','status':'warning retained'},
    {'theorem':'No co-Poisson overread','claim':'Burnol atom density only helps residual components visible in declared atom span','status':'warning retained'},
]).to_csv(out/'theorem_map_step116.csv', index=False)

pd.DataFrame([
    {'record':'P1 rewrite/gauge','step116 status':'residual sector is rewritten as Y_a-visible boundary packet Xi^BC','defect if missing':'undefined residual carrier'},
    {'record':'P2 feasibility/null legality','step116 status':'quotient by kernel of G_R,N and coefficient nulls','defect if missing':'false positive lower frame'},
    {'record':'P3 route/holonomy','step116 status':'shift modes ell are recorded as route labels','defect if missing':'untracked prime-shift sector'},
    {'record':'P4 staging/refinement','step116 status':'finite residual windows N and tail T_N','defect if missing':'moving-window support only'},
    {'record':'P5 packaging','step116 status':'Burnol/co-Poisson atom dictionary and coefficient synthesis D_N','defect if missing':'coefficient blind spot'},
    {'record':'P6 audit/currency','step116 status':'Loewner lower-frame inequalities and Lambda_N=gamma_N c_R,N','defect if missing':'scalar moment overread'},
]).to_csv(out/'all_six_residual_records_step116.csv', index=False)

nonclaim = '''# Step 116 nonclaim boundary

This step does not prove RH.

It does not prove that \(\Xi^{\rm BC}=0\).

It does not prove the Heap--Soundararajan operator-valued lift.

It does not prove that finite character windows exhaust the completed Burnol/Sonine residual sector.

It does not allow zero-simplicity assumptions or target-selected source families.

It proves a finite and completed theorem schema: if the residual sector is coefficient-visible and if Hecke/Dirichlet sources give a matrix lower frame whose strength overwhelms the visibility loss, then the boundary-to-co-Poisson residual is source-absorbed.
'''
(out/'nonclaim_boundary_step116.md').write_text(nonclaim)

schema = {
    'step':116,
    'title':'Residual-Specific Hecke/Dirichlet Source Absorption for Xi^BC',
    'objects':{
        'Xi_BC':'boundary-to-co-Poisson adequacy residual B^* Pi_Y B',
        'R_N':'coefficient map from residual sector to declared coefficient dictionary',
        'c_R_N':'residual coefficient visibility constant',
        'gamma_N':'character/source lower-frame strength',
        'Lambda_N':'effective source strength gamma_N*c_R_N',
        'F_R_N':'residual source frame R_N^* G_X_N R_N'
    },
    'acceptance':'Lambda_N -> infinity and fixed/exhaustive residual tails vanish',
    'failure_modes':['coefficient blind spot','scalar lower-moment overread','partial character coverage','moving-window tail','target-selected source family']
}
(out/'step116_schema.json').write_text(json.dumps(schema, indent=2))

# numerical sanity data
Ns = np.arange(8, 129, 8)
gamma = np.log(Ns+2)**2
c_good = 1 - 1/(Ns**0.7)
c_slow = 1/np.log(Ns+2)
c_bad = np.exp(-np.sqrt(Ns)/1.8)
sigma = np.ones_like(Ns)
rows=[]
for label,cvals in [('good_visibility',c_good),('slow_visibility',c_slow),('collapsing_visibility',c_bad)]:
    for N,g,c in zip(Ns,gamma,cvals):
        lam=g*c
        rows.append({'scenario':label,'N':int(N),'gamma_N':float(g),'c_R_N':float(c),'Lambda_N':float(lam),'absorption_factor_sigma_over_Lambda':float(1/lam)})
pd.DataFrame(rows).to_csv(out/'residual_source_absorption_scenarios_step116.csv', index=False)

# plots
plt.figure(figsize=(7,4.5))
for label,cvals in [('good',c_good),('slow',c_slow),('collapsing',c_bad)]:
    plt.plot(Ns,cvals,label=label)
plt.xlabel('finite residual window N')
plt.ylabel('visibility c_R,N')
plt.title('Residual coefficient visibility scenarios')
plt.legend()
plt.tight_layout()
plt.savefig(out/'residual_visibility_scenarios_step116.png', dpi=160)
plt.close()

plt.figure(figsize=(7,4.5))
for label,cvals in [('good',c_good),('slow',c_slow),('collapsing',c_bad)]:
    plt.plot(Ns,gamma*cvals,label=label)
plt.xlabel('finite residual window N')
plt.ylabel('effective strength Lambda_N = gamma_N c_R,N')
plt.title('Effective source strength')
plt.legend()
plt.tight_layout()
plt.savefig(out/'effective_source_strength_step116.png', dpi=160)
plt.close()

plt.figure(figsize=(7,4.5))
for label,cvals in [('good',c_good),('slow',c_slow),('collapsing',c_bad)]:
    plt.plot(Ns,1/(gamma*cvals),label=label)
plt.xlabel('finite residual window N')
plt.ylabel('sigma_N / Lambda_N')
plt.title('Residual absorption factor')
plt.legend()
plt.tight_layout()
plt.savefig(out/'residual_absorption_factor_step116.png', dpi=160)
plt.close()

# finite matrix checks
rng=np.random.default_rng(116)
check_rows=[]
partial_rows=[]
for d in [4,8,12,16,24,32]:
    A=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
    G=(A.conj().T@A)+0.5*np.eye(d)
    # coefficient visibility C = R^*H R: choose eigen values c_i between cmin and 1 wrt G
    cmin=0.15+0.5/(1+d/8)
    Q,_=np.linalg.qr(rng.normal(size=(d,d)))
    eig=np.linspace(cmin,1,d)
    Csqrt=np.linalg.cholesky(G)
    C=Csqrt.conj().T @ Q @ np.diag(eig) @ Q.T @ Csqrt
    gamma_d=np.log(d+3)
    F=gamma_d*C + 0.05*np.eye(d)
    # residual Xi <= sigma G
    sigma_d=0.7
    Xi=sigma_d*G*0.8
    slack=F-gamma_d*cmin*G
    evals=np.linalg.eigvalsh((slack+slack.conj().T)/2)
    bound_slack=(sigma_d/(gamma_d*cmin))*F-Xi
    evals2=np.linalg.eigvalsh((bound_slack+bound_slack.conj().T)/2)
    check_rows.append({'dimension':d,'gamma':gamma_d,'c_min':cmin,'min_slack_frame':float(evals.min()),'min_slack_absorption':float(evals2.min())})
    # partial source rank deficient
    r=max(1,d//2)
    P=np.zeros((d,d)); P[:r,:r]=np.eye(r)
    # random unitary basis and partial source
    U,_=np.linalg.qr(rng.normal(size=(d,d)))
    Fp=U@P@U.T
    partial_rows.append({'dimension':d,'source_rank':r,'min_eigen_partial_source':float(np.linalg.eigvalsh(Fp).min()),'nullity':int(d-r)})

pd.DataFrame(check_rows).to_csv(out/'finite_residual_absorption_checks_step116.csv', index=False)
pd.DataFrame(partial_rows).to_csv(out/'partial_source_failure_step116.csv', index=False)

plt.figure(figsize=(7,4.5))
ck=pd.DataFrame(check_rows)
plt.plot(ck['dimension'], ck['min_slack_frame'], label='frame slack')
plt.plot(ck['dimension'], ck['min_slack_absorption'], label='absorption slack')
plt.xlabel('dimension')
plt.ylabel('minimum certified slack eigenvalue')
plt.title('Finite residual absorption sanity checks')
plt.legend()
plt.tight_layout()
plt.savefig(out/'finite_residual_absorption_checks_step116.png', dpi=160)
plt.close()

plt.figure(figsize=(7,4.5))
pr=pd.DataFrame(partial_rows)
plt.plot(pr['dimension'], pr['min_eigen_partial_source'])
plt.xlabel('dimension')
plt.ylabel('minimum eigenvalue')
plt.title('Partial source coverage leaves a null sector')
plt.tight_layout()
plt.savefig(out/'partial_source_failure_step116.png', dpi=160)
plt.close()

check_script = r'''
import numpy as np

def min_eig(A):
    A=(A+A.conj().T)/2
    return np.linalg.eigvalsh(A).min()

rng=np.random.default_rng(116)
for d in [4,8,12,16]:
    A=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
    G=A.conj().T@A+np.eye(d)
    c=0.25
    gamma=2.0
    C=c*G+0.1*np.eye(d)
    F=gamma*C
    assert min_eig(F-gamma*c*G) > -1e-9
    Xi=0.5*G
    assert min_eig((0.5/(gamma*c))*F-Xi) > -1e-9
print('Step 116 finite residual absorption checks passed.')
'''
(out/'run_step116_residual_absorption_checks.py').write_text(check_script)

# zip
zip_path=out/'step116_residual_source_absorption_artifacts.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in out.iterdir():
        if p.name != zip_path.name:
            z.write(p, arcname=p.name)
print('created', zip_path)
