# Step 79: Archimedean, Pole, and Tail Balance Audit

This step audits how the non-prime completion terms must interact with the prime-slot diagonal repair.

## Core identity

For prime-shift weights \(w_a\), the signed prime autocorrelation term is

\[
P_{\rm pr}(h_f)=-\sum_a w_a(h_f(a)+h_f(-a)).
\]

The positive prime shift feature is

\[
q_{\rm pr}^+[f]=\sum_a w_a\|\tau_a f-f\|^2.
\]

Expanding gives

\[
q_{\rm pr}^+[f]=P_{\rm pr}(h_f)+d_{\rm pr}\|f\|^2,
\qquad d_{\rm pr}=2\sum_a w_a.
\]

Thus the prime slot becomes positive only after a diagonal repair.

## Completion-balance gate

Write the signed non-prime part of the completed explicit formula as

\[
R_{\rm sgn}=R_\infty+R_{\rm pole}+R_{\rm tail}.
\]

Let

\[
q_{\rm cmp}=q_{\rm pr}^+ + q_\infty^+ + q_{\rm pole}^+ + q_{\rm tail}^+.
\]

The completed-balance form is

\[
\mathcal B[f]
=d_{\rm pr}\|f\|^2+q_\infty^+[f]+q_{\rm pole}^+[f]+q_{\rm tail}^+[f]-R_{\rm sgn}[f].
\]

The required gate is

\[
\mathcal B\ge0.
\]

If it fails, the negative part is an explicit matching defect.

## Component conclusions

- The prime slot is positive after diagonal repair.
- The archimedean slot is plausibly positive as a renormalized shift-difference form, but exact gamma matching remains unearned.
- The pole/completion slot handles null and low-mode records; it cannot by itself dominate a full infinite-dimensional diagonal.
- The tail/support slot must supply finite-to-completed promotion and fixed/exhaustive ledger control.

## Active obstruction

The active RH analytic target is now:

\[
\boxed{\text{prove }\mathcal B\ge0\text{, or quantify }E_{\rm bal},\text{ for the actual completed zeta carrier}.}
\]
