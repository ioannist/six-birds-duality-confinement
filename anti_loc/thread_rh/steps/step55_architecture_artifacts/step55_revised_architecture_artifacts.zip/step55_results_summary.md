# Step 55: Revised manuscript architecture v0.4

This step re-architects the paper around **formed-layer membrane theory** rather than scalar anti-localization.

The new title is:

**Formed-Layer Membrane Theory: Anti-Localization, Adequacy, and the Root-Composite Obligation**

The center is now the formed-layer membrane theorem:

\[
	ext{formed closure} + 	ext{accepted predictive native test family} + \Xi	ext{-adequacy} + 	ext{all-six record}
\Rightarrow
	ext{no native or layer-dissolving predictive needles}.
\]

Anti-localization remains the main analytic consequence, but the framework is larger.

## Main architectural changes

1. **Scalar capacity moved down**: scalar \(\operatorname{Cap}_C(g)\) is now the one-probe shadow price special case.
2. **Probe-family currency is central**: \(\mathsf K_{C,\Gamma}(L)=L_\Gamma C_\Gamma^\dagger L_\Gamma^*\).
3. **\(\Xi\) is first-class**: \(\Xi_C(D\mid L)\) is now its own section and theorem cluster.
4. **Predictive membrane replaces static anti-loc**: the main condition is \(\widehat K_j\preceq\Theta\) for all accepted stages.
5. **All-six record is part of the theorem**: not an appendix; it is the acceptance condition.
6. **Root-composite RH is an obligation**: it remains open and is framed by \(\mathsf A_Z\preceq\mathsf K^-\preceq\Theta^-\).
7. **Navier is a short adequacy map**: no diversion into NS; it demonstrates \(\Xi\)'s usefulness.

## Next best move

The next proof step should be a short, targeted theorem that improves the manuscript without growing applications:

**Step 56: probe-class robustness theorem**

Classify native probe classes by automatic or conditional membrane behavior:

- parity-like / average-like probes: structurally robust,
- delta-like probes: structurally needle-prone,
- coherent superpositions: conditioning-dependent.

This would give the theory a practical diagnostic taxonomy and connect strongly to the corpus-lens XOR/parity insight.
