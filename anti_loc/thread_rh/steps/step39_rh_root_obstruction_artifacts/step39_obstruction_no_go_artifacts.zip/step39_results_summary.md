# Step 39: Obstruction Ledger for the Root-Composite RH Route

## Purpose

Step 38 gave a forward theorem:

\[
\text{EF domination} + \text{anti-invariant source collapse}
\Rightarrow
\text{zero/root confinement}.
\]

Step 39 proves the contrapositive ledger: if the confinement conclusion is not obtained under a claimed budget, then a named obstruction must be present.

## Main obstruction theorem

Let

\[
B_{t,\Lambda}=(1+t)(\Lambda^{-1}\Theta_0^-+E_{\rm src})+(1+t^{-1})E_{\rm EF}.
\]

If

\[
\sum_{z:\|\psi(z)\|\ge\varepsilon}w_z>
\varepsilon^{-2}\operatorname{tr}B_{t,\Lambda},
\]

then at least one obstruction is active:

1. explicit-formula domination failure;
2. source/coercivity failure;
3. character-frame hole;
4. null-mode legality failure;
5. zero visibility/exhaustivity failure;
6. no-smuggling/public-shadow failure.

Each matrix failure has a separating vector witness.

## Why this matters

The root-composite RH route is now falsifiable.  If the route does not prove confinement, the failure is no longer vague: it must be placed in one of the ledger slots.

## Layman interpretation

If off-line zeros remain, then something in the proof ledger failed. Either the explicit formula did not really charge the off-line displacement, the character sources did not cover all off-line directions, the budget did not shrink, a zero-energy loophole remained, the zero ledger missed something, or the proof used a public shadow instead of the lawful carrier witness.

## Status

This is not an RH proof. It is a no-go/obstruction theorem for the proposed root-composite RH anti-localization route.
