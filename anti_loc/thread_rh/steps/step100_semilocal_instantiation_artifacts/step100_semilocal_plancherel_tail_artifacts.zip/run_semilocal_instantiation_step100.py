import json, math, cmath, csv
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import mpmath as mp

OUT = Path('/mnt/data/rh_membrane_step100_semilocal_instantiation')
OUT.mkdir(parents=True, exist_ok=True)

# Local factor and archimedean weight model for the semilocal response measure.
def L_p(p, s):
    # s is real frequency xi in L_p(1/2 - i xi)
    return 1.0 / (1.0 - p**(-0.5 + 1j*s))

def L_inf_abs2(s):
    # |pi^{-z/2} Gamma(z/2)|^2 at z=1/2 - i s
    z = 0.5 - 1j*s
    val = mp.pi**(-z/2) * mp.gamma(z/2)
    return float(abs(val)**2)

def dm_weight(s, primes):
    w = L_inf_abs2(s)
    for p in primes:
        w *= abs(L_p(p, s))**2
    return w

# Grid avoiding very large gamma values; gamma factor decays fast for large |s|.
xs = np.linspace(0, 40, 801)
prime_sets = [[], [2], [2,3], [2,3,5]]
rows=[]
for S in prime_sets:
    weights=[]
    for x in xs:
        weights.append(dm_weight(float(x), S))
    maxw=max(weights); minw=min(weights)
    rows.append({'primes':'empty' if not S else ','.join(map(str,S)), 'min_weight':minw, 'max_weight':maxw, 'weight_at_0':weights[0], 'weight_at_20':weights[np.searchsorted(xs,20)]})
# Write sampled weight profile for S=[2,3,5]
with open(OUT/'semilocal_measure_weight_step100.csv','w',newline='') as f:
    wr=csv.writer(f)
    wr.writerow(['xi','dm_empty','dm_2','dm_23','dm_235'])
    for x in xs:
        wr.writerow([x, dm_weight(float(x),[]), dm_weight(float(x),[2]), dm_weight(float(x),[2,3]), dm_weight(float(x),[2,3,5])])
with open(OUT/'semilocal_measure_summary_step100.csv','w',newline='') as f:
    wr=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    wr.writeheader(); wr.writerows(rows)

plt.figure(figsize=(7,4.5))
for S,label in zip(prime_sets,['empty','{2}','{2,3}','{2,3,5}']):
    ys=np.array([dm_weight(float(x),S) for x in xs])
    plt.semilogy(xs, ys, label=label)
plt.xlabel(r'$\xi$')
plt.ylabel(r'$dm_S/d\xi$')
plt.title('Semilocal response measure weights')
plt.legend()
plt.tight_layout()
plt.savefig(OUT/'semilocal_measure_weight_step100.png', dpi=180)
plt.close()

# Tail models: trace-class ledger density relative to dxi or relative to dm_S.
Ts = np.linspace(1,40,80)
# Algebraic tail model density (1+x^2)^-alpha on both sides. tail = 2 int_T inf density dx approximate.
def alg_tail(T, alpha):
    # numeric integrate with mpmath
    f=lambda u: (1+u*u)**(-alpha)
    return float(2*mp.quad(f, [T, mp.inf]))

tail_rows=[]
for T in Ts:
    # exponential toy tail with gamma-like decay exp(-pi x/2)
    exp_tail=float(2*(2/mp.pi)*mp.e**(-mp.pi*T/2))
    row={'T':T, 'exp_gamma_tail':exp_tail}
    for alpha in [1.1,1.5,2.0,3.0]:
        row[f'alg_tail_alpha_{alpha}']=alg_tail(T,alpha)
    tail_rows.append(row)
with open(OUT/'tail_exhaustivity_models_step100.csv','w',newline='') as f:
    wr=csv.DictWriter(f, fieldnames=list(tail_rows[0].keys()))
    wr.writeheader(); wr.writerows(tail_rows)

plt.figure(figsize=(7,4.5))
plt.semilogy(Ts, [r['exp_gamma_tail'] for r in tail_rows], label='gamma-like exp tail')
for alpha in [1.1,1.5,2.0,3.0]:
    plt.semilogy(Ts, [r[f'alg_tail_alpha_{alpha}'] for r in tail_rows], label=f'algebraic alpha={alpha}')
plt.xlabel('window height T')
plt.ylabel('model zero-ledger tail')
plt.title('Fixed/exhaustive ledger tail models')
plt.legend()
plt.tight_layout()
plt.savefig(OUT/'tail_exhaustivity_models_step100.png', dpi=180)
plt.close()

# Budget collapse toy: Lambda_T = T^beta, tail = T^-gamma; combined optimized squeeze.
budget_rows=[]
Ts2=np.arange(2,101)
for beta in [0.5,1.0,1.5,2.0]:
    for gamma in [0.5,1.0,2.0]:
        for T in Ts2:
            a=T**(-beta)
            b=T**(-gamma)
            opt=(math.sqrt(a)+math.sqrt(b))**2
            budget_rows.append({'beta':beta,'gamma':gamma,'T':T,'lambda_inv':a,'tail':b,'optimized_squeeze':opt})
with open(OUT/'budget_collapse_model_step100.csv','w',newline='') as f:
    wr=csv.DictWriter(f, fieldnames=list(budget_rows[0].keys()))
    wr.writeheader(); wr.writerows(budget_rows)

plt.figure(figsize=(7,4.5))
for beta,gamma in [(1.0,1.0),(1.0,2.0),(2.0,1.0),(2.0,2.0)]:
    vals=[r['optimized_squeeze'] for r in budget_rows if r['beta']==beta and r['gamma']==gamma]
    plt.loglog(Ts2, vals, label=f'beta={beta}, gamma={gamma}')
plt.xlabel('T')
plt.ylabel(r'$(\sqrt{\Lambda_T^{-1}}+\sqrt{\tau_T})^2$')
plt.title('Completed squeeze: lower-frame growth plus tail decay')
plt.legend()
plt.tight_layout()
plt.savefig(OUT/'completed_squeeze_budget_step100.png', dpi=180)
plt.close()

# Moving window failure demonstration: each window exact, no tail -> hidden mass remains.
move_rows=[]
for T in Ts2:
    visible=0.0
    hidden=1.0
    move_rows.append({'T':T,'visible_bound':visible,'hidden_tail_without_record':hidden,'status':'support_only'})
with open(OUT/'moving_window_failure_step100.csv','w',newline='') as f:
    wr=csv.DictWriter(f, fieldnames=list(move_rows[0].keys()))
    wr.writeheader(); wr.writerows(move_rows)

plt.figure(figsize=(7,4.5))
plt.plot(Ts2, [r['visible_bound'] for r in move_rows], label='finite-window bound')
plt.plot(Ts2, [r['hidden_tail_without_record'] for r in move_rows], label='unrecorded hidden tail')
plt.xlabel('window index')
plt.ylabel('obstruction mass')
plt.title('Moving-window support-only failure')
plt.legend()
plt.tight_layout()
plt.savefig(OUT/'moving_window_failure_step100.png', dpi=180)
plt.close()

# Gate/status tables
import pandas as pd
pd.DataFrame([
    {'gate':'carrier space','carrier-native record':r'Y_S^- = L^2(R,dm_S)^-','status':'instantiated'},
    {'gate':'window map','carrier-native record':r'Pi_T=P_T=1_{[-T,T]}','status':'instantiated'},
    {'gate':'zero-ledger tail','carrier-native record':r'tau_Z(T)=tr(R_T A_Z R_T)','status':'requires trace-class/fixed ledger'},
    {'gate':'finite source frame','carrier-native record':r'F_T^{win} >= Lambda_T P_T Theta^{-1} P_T','status':'open arithmetic input'},
    {'gate':'completed lower frame','carrier-native record':r'F_T + Lambda_T T_T >= Lambda_T Theta^{-1}','status':'tail-dependent'},
    {'gate':'semilocal Delta absorption','carrier-native record':r'P_T Delta_S^+ P_T <= F_T^{win}+E_T','status':'open analytic input'},
    {'gate':'exact confinement squeeze','carrier-native record':r'tr(B_T)+tr(E_T)+tau_Z(T)->0','status':'framework theorem'},
]).to_csv(OUT/'semilocal_instantiation_gate_table_step100.csv', index=False)

pd.DataFrame([
    {'component':'Connes-Consani-Moscovici response space','instantiated as':r'L^2(R,dm_S), dm_S=|prod_v L_v(1/2-is)|^2 ds','role':'completed semilocal room'},
    {'component':'anti-invariant sector','instantiated as':r'J_S y(s)=conj(y(-s)), J_S y=-y','role':'fixed-locus displacement sector'},
    {'component':'spectral window','instantiated as':r'P_T=1_{[-T,T]}','role':'finite-window ledger'},
    {'component':'tail','instantiated as':r'R_T=I-P_T, tau_Z(T)=tr(R_T A_Z R_T)','role':'promotion/exhaustivity'},
    {'component':'source frame','instantiated as':r'sum lambda Q^* Theta^{-1} Q on P_TY_S^-','role':'future Hecke/Dirichlet lower frame'},
    {'component':'Delta_S','instantiated as':r'q_Weil,S - q_pos,S','role':'semilocal cross-term obstruction'},
]).to_csv(OUT/'carrier_objects_step100.csv', index=False)

pd.DataFrame([
    {'theorem':'Trace-class exhaustion','statement':'P_T increases strongly to I, A_Z trace-class implies tr(R_T A_Z R_T)->0','status':'proved'},
    {'theorem':'Semilocal window promotion','statement':'window squeeze plus tail squeeze implies A_Z=0','status':'proved'},
    {'theorem':'Completed lower-frame gate','statement':'finite lower frame promotes only with tail form T_T','status':'proved as criterion'},
    {'theorem':'RH source route condition','statement':'need P_T Delta_S^+ P_T <= F_T^win+E_T and Lambda_T->infty','status':'open input'},
]).to_csv(OUT/'theorem_map_step100.csv', index=False)

schema={
  'step':100,
  'title':'Semilocal Plancherel/Tail Instantiation',
  'carrier':'Y_S^- = L^2(R, dm_S)^-',
  'measure':'dm_S(s)=|prod_{v in S} L_v(1/2-is)|^2 ds',
  'window_maps':{'P_T':'multiplication by 1_{[-T,T]}','Pi_T':'restriction to P_TY_S^-','R_T':'I-P_T'},
  'tail_record':'tau_Z(T)=tr(R_T A_Z R_T)->0',
  'lower_frame_target':'F_T^win >= Lambda_T P_T (Theta_0^-)^{-1} P_T',
  'delta_absorption_target':'P_T Delta_S^+ P_T <= F_T^win + E_abs,T',
  'nonclaims':['does not prove RH','does not prove Delta_S compactness','does not prove Hecke lower frame','does not prove tail trace-classity for the actual zero ledger'],
  'next_step':'Semilocal Delta_S compactness/prolate-extension test'
}
with open(OUT/'step100_schema.json','w') as f: json.dump(schema,f,indent=2)
