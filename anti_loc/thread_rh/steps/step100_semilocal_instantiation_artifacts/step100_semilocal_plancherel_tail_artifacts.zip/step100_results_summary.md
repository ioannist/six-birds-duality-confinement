# Step 100: Semilocal Plancherel/Exhaustivity Instantiation

## Result

The abstract Step 99 promotion theorem has now been instantiated on the semilocal Connes--Consani--Moscovici response carrier

\[
Y_S^- = L^2(\mathbb R,dm_S)^-,
\qquad
 dm_S(\xi)=\left|\prod_{v\in S}L_v\left(\frac12-i\xi\right)\right|^2d\xi.
\]

This carrier gives explicit native objects:

- spectral window maps \(P_T\),
- finite-place transition maps \(U_{S\to S'}\),
- spectral tail forms \(T_{S,T}\),
- place-tail / measure-change records,
- a precise room for the semilocal cross-term \(\Delta_S\).

## Main theorem

If a finite/windowed source frame satisfies

\[
F_{S,T}^{\rm win}\succeq \Lambda_{S,T}B_{S,T},
\]

and the semilocal carrier has an exhaustivity record

\[
(\Theta_0^-)^{-1}\preceq P_T^*B_{S,T}P_T+T_{S,T},
\]

then the lifted source frame satisfies

\[
F_{S,T}+\Lambda_{S,T}T_{S,T}
\succeq
\Lambda_{S,T}(\Theta_0^-)^{-1}.
\]

Equivalently,

\[
F_{S,T}
\succeq
\Lambda_{S,T}(\Theta_0^-)^{-1}
-
\Lambda_{S,T}T_{S,T}.
\]

So finite semilocal certificates promote only up to an explicit tail form.

## Key verdict

\[
\boxed{
\text{pure semilocal }Y_S^-\text{ is the right room for }\Delta_S,
\text{ but not enough for full character-source coercivity.}
}
\]

Reason: the Connes--Consani--Moscovici semilocal response space is the \(K_S\)-invariant spherical response. Nontrivial compact/Hecke character directions are suppressed. Therefore a full Hecke/Dirichlet character-source lower frame requires either:

1. an augmented semilocal carrier retaining \(K_S\)-Fourier modes;
2. an enlarged Hecke/idèle carrier;
3. or a descent bridge proving that character-source coercivity descends to the spherical semilocal response space.

## Strategic consequence

Before committing to a heavier enlarged carrier, the highest-leverage next move is to test whether \(\Delta_S\) is compact-after-quotient / finite-rank / tail-defect inside the semilocal prolate/Sonin machinery.

If yes, source absorption becomes elementary functional analysis.

If no, then \(\Delta_S\) is a genuine full-sector obstruction and the program must move to the augmented Hecke-character carrier.

## Layman interpretation

The semilocal carrier is the room where primes and gamma are measured together.

It gives us honest finite windows and honest tail records. But it does not yet contain all arithmetic character sensors. So it can tell us where the unpaid cross-term \(\Delta_S\) lives, but it cannot by itself prove that every hidden off-critical direction is charged.

The next decisive question is:

> Is \(\Delta_S\) compact or tail-like in this room?

If yes, it can be absorbed. If no, we need the bigger Hecke carrier.
