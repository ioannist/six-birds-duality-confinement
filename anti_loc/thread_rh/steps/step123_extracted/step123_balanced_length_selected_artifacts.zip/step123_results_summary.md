
# Step 123: Balanced-Length Theorem

This step chooses growth regimes for the regularized Müntz/co-Poisson shadow and the Hecke/Dirichlet source family.

The key compatibility problem is:

\[
\text{Müntz shadow long enough for accuracy}
\quad\text{and}\quad
\text{Dirichlet polynomial short enough for source estimates}.
\]

Let:

\[
T_N=Q_N^t,
\quad
A_N\le Q_N^a,
\quad
X_N=Q_N^x,
\quad
R_N=Q_N^r.
\]

Assume:

\[
\tau_{M,N}\le C A_N T_N^\alpha X_N^{-\eta},
\]

\[
\epsilon_{\rm Mell,N}+\kappa_{\rm tail,N}\le C A_NR_N^{-\beta},
\]

and the source estimates require:

\[
X_NR_N\le Q_N^{\theta_{\rm src}}.
\]

Then a vanishing-error, short-polynomial regime exists iff:

\[
\boxed{
\frac{a+\alpha t}{\eta}+\frac{a}{\beta}<\theta_{\rm src}.
}
\]

This is the balanced-length theorem.

## Strategic consequence

The same-aspect route \(T_N\asymp Q_N\) is likely underpowered if one uses Heap--Soundararajan-style short-polynomial technology without improvement.  In the simplest bounded-complexity case, it needs:

\[
\frac{\alpha}{\eta}<\theta_{\rm src}.
\]

For a short source range such as \(\theta_{\rm src}\approx 1/9\), this is hard unless the Müntz contour residual has unusually strong decay.

So the viable route is conductor decoupling:

\[
\boxed{
Q_N\gg T_N.
}
\]

That is, use Dirichlet/Hecke conductor growth to give the source family enough room, while keeping the Müntz vertical window moderate.

## Effective source strength

The residual source route now requires:

\[
\boxed{
\gamma_N\left[1-(\epsilon_{B,N}+\epsilon_{\rm Mell,N}+\tau_{M,N}+\kappa_{\rm tail,N})^2\right]\to\infty.
}
\]

A positive visibility floor may be enough if \(\gamma_N\to\infty\), but exact RH still needs fixed/exhaustive ledger promotion.

## Verdict

Step 123 does not prove RH. It identifies the new quantitative obstruction and points to the next viable route:

\[
\boxed{
\text{conductor-decoupled Hecke/Dirichlet source ladder.}
}
\]
