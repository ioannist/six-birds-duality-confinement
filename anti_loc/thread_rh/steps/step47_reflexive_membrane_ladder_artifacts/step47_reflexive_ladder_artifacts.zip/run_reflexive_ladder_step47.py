#!/usr/bin/env python3
"""Small algebra sanity checks for Step 47.
These are not Six Birds simulations; they only illustrate the proved PSD recurrences.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

OUT = Path('/mnt/data/anti_localization_step47_reflexive_ladder')
OUT.mkdir(parents=True, exist_ok=True)

# 1. Persistent summable-defect ladder, scalar model
rows=[]
K=0.2
Theta=1.0
for n in range(1,201):
    eps=0.01/(n*n)
    D=0.002/(n*n)
    K=(1+eps)*K+D
    rows.append({'n':n,'epsilon':eps,'D':D,'K':K,'Theta':Theta,'complete':K<=Theta})
pd.DataFrame(rows).to_csv(OUT/'persistent_summable_ladder_step47.csv',index=False)
plt.figure(figsize=(7,4))
plt.plot([r['n'] for r in rows],[r['K'] for r in rows],label='K_n')
plt.axhline(Theta,linestyle='--',label='Theta')
plt.xlabel('stage n')
plt.ylabel('currency budget')
plt.title('Persistent membrane under summable defects')
plt.legend()
plt.tight_layout()
plt.savefig(OUT/'persistent_summable_ladder_step47.png',dpi=180)
plt.close()

# 2. Monotone improvement no finite completion
rows=[]
Theta=1.0
for n in range(1,501):
    K=1+1/n
    rows.append({'n':n,'K':K,'Theta':Theta,'defect':K-Theta,'complete':K<=Theta})
pd.DataFrame(rows).to_csv(OUT/'monotone_no_finite_completion_step47.csv',index=False)
plt.figure(figsize=(7,4))
plt.plot([r['n'] for r in rows],[r['defect'] for r in rows])
plt.xlabel('stage n')
plt.ylabel('positive defect')
plt.title('Monotone improvement without finite completion')
plt.tight_layout()
plt.savefig(OUT/'monotone_no_finite_completion_step47.png',dpi=180)
plt.close()

# 3. Non-summable predictive defect ladder
rows=[]
K=0.0
for n in range(1,501):
    K += 1/n
    rows.append({'n':n,'K':K,'increment':1/n})
pd.DataFrame(rows).to_csv(OUT/'nonsummable_predictive_defect_step47.csv',index=False)
plt.figure(figsize=(7,4))
plt.plot([r['n'] for r in rows],[r['K'] for r in rows])
plt.xlabel('stage n')
plt.ylabel('K_n')
plt.title('Non-summable predictive defect grows unbounded')
plt.tight_layout()
plt.savefig(OUT/'nonsummable_predictive_defect_step47.png',dpi=180)
plt.close()

# 4. Finite witness elimination example
witnesses = ['slow_mode','route_mix','recombination','future_refinement','public_shadow']
rows=[]
unresolved=witnesses.copy()
for n in range(len(witnesses)+1):
    rows.append({'stage':n,'unresolved_count':len(unresolved),'unresolved':';'.join(unresolved),'complete':len(unresolved)==0})
    if unresolved:
        unresolved.pop(0)
pd.DataFrame(rows).to_csv(OUT/'finite_witness_elimination_step47.csv',index=False)

# 5. Random PSD recurrence sanity check
rng=np.random.default_rng(47)
records=[]
for trial in range(50):
    dim=4
    A=rng.normal(size=(dim,dim))
    K=A@A.T
    Theta=2.5*K + np.eye(dim)
    for n in range(5):
        eps=0.02/(n+1)**2
        B=rng.normal(size=(dim,dim))
        D=(B@B.T)*0.001/(n+1)**2
        K_next=(1+eps)*K + D
        # choose compatible budget update
        Theta_next=(1+eps)*Theta + D
        margin=np.linalg.eigvalsh(Theta_next-K_next).min()
        records.append({'trial':trial,'stage':n,'eps':eps,'min_margin':margin,'passed':margin>=-1e-9})
        K,Theta=K_next,Theta_next
pd.DataFrame(records).to_csv(OUT/'random_psd_propagation_checks_step47.csv',index=False)

print('Step 47 checks complete.')
