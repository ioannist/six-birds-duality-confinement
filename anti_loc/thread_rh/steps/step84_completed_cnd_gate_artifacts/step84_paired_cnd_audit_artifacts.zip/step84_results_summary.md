# Step 84: Paired Completed Weil Symbol Audit and the CND Gate

This step audits the paired completed Weil feature target after the no-free-diagonal result of Step 82.

## Main result

A log-side paired shift feature has form

\[
q_\mu[f]=\int \|\tau_a f-f\|_2^2\,d\mu(a),\qquad \mu\ge0.
\]

Its Fourier symbol is

\[
\Psi_\mu(\xi)=2\int(1-\cos(a\xi))\,d\mu(a).
\]

Thus the right gate is not merely nonnegativity. The symbol must be continuous negative definite / Levy--Khintchine:

\[
\Psi(\xi)=c\xi^2+2\int(1-\cos(a\xi))\,d\mu(a),\qquad c\ge0,\quad \mu\ge0.
\]

## Prime and gamma slots

The finite prime-power slot

\[
\Psi_{{\rm pr},L}(\xi)=2\sum_n w_{n,L}(1-\cos(\xi\log n))
\]

is CND, with finite atomic Levy measure.

The normalized gamma slot

\[
\Psi_\Gamma(\xi)=\frac12\left(\Re\psi\left(\frac14+\frac{i\xi}{2}\right)-\psi\left(\frac14\right)\right)
\]

has the positive paired representation

\[
\Psi_\Gamma(\xi)=\frac12\int_0^\infty \frac{e^{-t/4}}{1-e^{-t}}
\left(1-\cos\frac{\xi t}{2}\right)\,dt.
\]

Therefore prime plus gamma is a lawful paired feature symbol at the symbolic level.

## Warning

A nonnegative symbol need not be a paired shift feature. The finite CND test is

\[
\sum_{i,j}c_ic_j\Psi(x_i-x_j)\le0,\qquad \sum_i c_i=0.
\]

The sanity checks show prime, gamma, and prime+gamma pass this test in random trials, while the nonnegative symbol \((1-\cos\xi)^2\) fails.

## RH status

This still does **not** prove RH. It proves that the candidate prime and gamma slots pass the paired-feature gate. The remaining analytic obligation is:

\[
q_Z[f]\le q_{\rm cmp}[f]
\]

on the completed anti-invariant core, with pole/tail/null records and fixed/exhaustive zero-ledger squeeze.

## Bottom line

The active target has shifted from separated diagonal accounting to paired completed Weil feature domination:

\[
V_Z^*V_Z\preceq W_{\rm cmp}^*W_{\rm cmp}.
\]

Prime and gamma slots pass the CND gate. Matching the paired completed carrier to the actual explicit formula remains open.
